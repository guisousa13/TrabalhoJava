/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projetoaula;

/**
 *
 * @author alunocmc
 */
public class ProjetoAula {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
    public static boolean checkLogin(String usuario, String senha){
    
        return usuario.equals("Admin") && senha.equals("123");
    
    }
    
    
    
}
